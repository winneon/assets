function init () 
{
	updateClock();
	setInterval('updateClock()', 1000);
}

function updateClock ()
{
	var currentClockTime = new Date();
	var currentClockHours = currentClockTime.getHours();
	var currentClockMinutes = currentClockTime.getMinutes();

	//Check if the time is AM or PM
	var timeOfDay = ( currentClockHours < 12 ) ? "A.M" : "P.M";

	//If not in 24 hour mode
	if (twentyfourHour == false) 
	{
		//Convert to 12 hour time
		currentClockHours = ( currentClockHours > 12 ) ? currentClockHours - 12 : currentClockHours;
		currentClockHours = ( currentClockHours == 0 ) ? 12 : currentClockHours;
	}

	//Pad with zeroes
	currentClockHours = ( currentClockHours < 10 ? "0" : "" ) + currentClockHours;
	currentClockMinutes = ( currentClockMinutes < 10 ? "0" : "" ) + currentClockMinutes;

	//Convert the time into strings, split the two numbers
	var currentMinutes = String(currentClockMinutes);
	var currentHours = String(currentClockHours);
	currentMinutes = currentMinutes.split("");
	currentHours = currentHours.split("");

	//Create the string to be displayed
	currentTimeString = currentHours[0] + currentHours[1] + ':' + currentMinutes[0] + currentMinutes[1]

	//Update the time
	document.getElementById("clock").innerHTML = currentTimeString;
}