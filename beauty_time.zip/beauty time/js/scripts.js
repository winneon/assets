var fontSize = 50; //CHANGE THIS TO CHANGE FONT SIZE
var onesStrArr;
var teensStrArr;
var tensStrArr;
var daysStrArr;

function initialize() {

    assignDefaultValues();
    getTimeDayDate();

}

function assignDefaultValues() {

    onesStrArr = new Array("zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve");
    teensStrArr = new Array("ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen");
    tensStrArr = new Array("twenty", "thirty", "forty", "fifty");
    daysStrArr = new Array("sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday");

}

function getTimeDayDate()  {

    var dateDayTime = new Date();
    var day = getCurrDay(dateDayTime);
    var time = getCurrTime(dateDayTime);
    var date = getNumCurrDate(dateDayTime);
    //document.getElementById("day").innerHTML = day;
    $("#time").html(time);
    $("#time").css('font-size', fontSize);
    console.log(time);
    //document.getElementById("date").innerHTML = date;
    setTimeout("getTimeDayDate()", 1000);

}

function getCurrTime(dateDayTime) {

    var hours = dateDayTime.getHours();
    var minutes = dateDayTime.getMinutes();
    var seconds = dateDayTime.getSeconds();
    if (hours > 12)
        hours = hours - 12;
    if (hours == 0)
        hours = 12;
    //hours
    var hourStr = onesStrArr[hours];
    //minutes
    var minutesStr;
    if (minutes == 0)
        minutesStr = "o'clock";
    else if (minutes <= 9)
        minutesStr = "o'" + " " + onesStrArr[minutes];
    else if (minutes > 9 && minutes < 20)
        minutesStr = teensStrArr[minutes - 10];
    else {
        var tensPlace = "";
        var onesPlace = "";
        tensPlace = tensStrArr[Math.floor((minutes - 20) / 10)];
        if (minutes % 10 > 0)
            onesPlace = onesStrArr[minutes % 10];
        minutesStr = tensPlace + " " + onesPlace;
    }
    return hourStr + " " + minutesStr;
}

function getCurrDay(dateDayTime) {

    var day = dateDayTime.getDay();
    return daysStrArr[day];
}

function getNumCurrDate(dateDayTime) {
    var month = dateDayTime.getMonth();
    var date = dateDayTime.getDate();
    var year = new String(dateDayTime.getFullYear());
    month = month + 1;
    year = year.substr(2, 4);
    return month + "." + date + "." + year;

}